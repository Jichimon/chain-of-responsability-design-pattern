﻿namespace Uagrm.Sa.DesignPatterns.LoanProcessor.Domain.Interfaces;

public interface ILogger
{
    public void Log(string message);
}
